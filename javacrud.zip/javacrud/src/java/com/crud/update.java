
package com.crud;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class update extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      
     String id = req.getParameter("id");
     String uname = req.getParameter("uname");
     String upassword = req.getParameter("upassword");
     
      System.out.println(uname + upassword);
      
       try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con =DriverManager.getConnection("jdbc:derby://localhost:1527/javacrud", "java", "java");
            PreparedStatement ps = con.prepareStatement("Update insertdata set uname=?,upassword=? where id=" + id);
            ps.setString(1, uname);
            ps.setString(2, upassword);
            int i = ps.executeUpdate();
            if (i > 0) {
                resp.sendRedirect("index.jsp");
            } else {
                out.print("There is a problem in updating Record.");
            }
       
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(update.class.getName()).log(Level.SEVERE, null, ex);
    
    }   catch (SQLException ex) {
            Logger.getLogger(update.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
}
